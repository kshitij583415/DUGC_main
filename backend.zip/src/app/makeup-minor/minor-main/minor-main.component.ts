import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-minor-main',
  templateUrl: './minor-main.component.html',
  styleUrls: ['./minor-main.component.css']
})
export class MinorMainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
