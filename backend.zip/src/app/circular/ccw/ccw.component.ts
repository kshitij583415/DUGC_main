import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ccw',
  templateUrl: './ccw.component.html',
  styleUrls: ['./ccw.component.css']
})
export class CcwComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
