import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cin',
  templateUrl: './cin.component.html',
  styleUrls: ['./cin.component.css']
})
export class CinComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
