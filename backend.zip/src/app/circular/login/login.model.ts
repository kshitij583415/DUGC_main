export class LoginModel
{
    name:any;
    password:any;
}