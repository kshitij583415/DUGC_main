import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cam',
  templateUrl: './cam.component.html',
  styleUrls: ['./cam.component.css']
})
export class CamComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
