import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nm',
  templateUrl: './nm.component.html',
  styleUrls: ['./nm.component.css']
})
export class NmComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
