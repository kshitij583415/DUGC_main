import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cmm',
  templateUrl: './cmm.component.html',
  styleUrls: ['./cmm.component.css']
})
export class CmmComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
