import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upload-sheets',
  templateUrl: './upload-sheets.component.html',
  styleUrls: ['./upload-sheets.component.css']
})
export class UploadSheetsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
