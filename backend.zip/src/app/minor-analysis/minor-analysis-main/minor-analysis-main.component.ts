import { Component, OnInit } from '@angular/core';
import { NavbarComponent } from '../navbar/navbar.component';
@Component({
  selector: 'app-minor-analysis-main',
  templateUrl: './minor-analysis-main.component.html',
  styleUrls: ['./minor-analysis-main.component.css'],
})
export class MinorAnalysisMainComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
