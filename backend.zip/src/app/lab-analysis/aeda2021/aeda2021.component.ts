import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aeda2021',
  templateUrl: './aeda2021.component.html',
  styleUrls: ['./aeda2021.component.css']
})
export class Aeda2021Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
