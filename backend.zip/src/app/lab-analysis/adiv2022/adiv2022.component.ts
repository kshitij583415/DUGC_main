import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adiv2022',
  templateUrl: './adiv2022.component.html',
  styleUrls: ['./adiv2022.component.css']
})
export class Adiv2022Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
