import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-amcp2021',
  templateUrl: './amcp2021.component.html',
  styleUrls: ['./amcp2021.component.css']
})
export class Amcp2021Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
