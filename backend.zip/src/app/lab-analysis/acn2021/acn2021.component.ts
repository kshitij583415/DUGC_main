import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-acn2021',
  templateUrl: './acn2021.component.html',
  styleUrls: ['./acn2021.component.css']
})
export class Acn2021Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
