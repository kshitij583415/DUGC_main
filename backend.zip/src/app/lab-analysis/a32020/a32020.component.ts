import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-a32020',
  templateUrl: './a32020.component.html',
  styleUrls: ['./a32020.component.css']
})
export class A32020Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
