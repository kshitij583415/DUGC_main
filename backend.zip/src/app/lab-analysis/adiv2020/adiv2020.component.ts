import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adiv2020',
  templateUrl: './adiv2020.component.html',
  styleUrls: ['./adiv2020.component.css']
})
export class Adiv2020Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
