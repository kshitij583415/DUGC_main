import { Component, OnInit } from '@angular/core';
import { HomeComponent } from '../home/home.component';
@Component({
  selector: 'app-lab-analysis-main',
  templateUrl: './lab-analysis-main.component.html',
  styleUrls: ['./lab-analysis-main.component.css'],
})
export class LabAnalysisMainComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
