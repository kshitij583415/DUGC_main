import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aml2021',
  templateUrl: './aml2021.component.html',
  styleUrls: ['./aml2021.component.css']
})
export class Aml2021Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
