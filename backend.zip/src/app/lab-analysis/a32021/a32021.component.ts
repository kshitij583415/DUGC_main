import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-a32021',
  templateUrl: './a32021.component.html',
  styleUrls: ['./a32021.component.css']
})
export class A32021Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
