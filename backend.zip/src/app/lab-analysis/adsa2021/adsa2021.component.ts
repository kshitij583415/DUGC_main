import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adsa2021',
  templateUrl: './adsa2021.component.html',
  styleUrls: ['./adsa2021.component.css']
})
export class Adsa2021Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
