import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adiv2021',
  templateUrl: './adiv2021.component.html',
  styleUrls: ['./adiv2021.component.css']
})
export class Adiv2021Component{

  constructor() { }

  ngOnInit() {}
}
