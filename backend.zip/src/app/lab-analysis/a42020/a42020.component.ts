import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-a42020',
  templateUrl: './a42020.component.html',
  styleUrls: ['./a42020.component.css']
})
export class A42020Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
