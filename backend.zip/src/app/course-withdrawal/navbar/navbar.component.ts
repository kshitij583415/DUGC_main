import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navbar-withdrawal',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css'],
})
export class WithdrawalNavbarComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
