// Using module.exports

const Roles = {
  DUGCCHAIRMAN: "DUGCCHAIRMAN",
  DUGCCORD: "DUGCCORD",
  FACULTYCORD: "FACULTYCORD",
  FACULTY: "FACULTY",
};

module.exports = Roles;
