import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eligibility-home',
  templateUrl: './eligibility-home.component.html',
  styleUrls: ['./eligibility-home.component.css']
})
export class EligibilityHomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
