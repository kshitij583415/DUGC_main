import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-a42021',
  templateUrl: './a42021.component.html',
  styleUrls: ['./a42021.component.css']
})
export class A42021Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
