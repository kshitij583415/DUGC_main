import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-awt2021',
  templateUrl: './awt2021.component.html',
  styleUrls: ['./awt2021.component.css']
})
export class Awt2021Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
