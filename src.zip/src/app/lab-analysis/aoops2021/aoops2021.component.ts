import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aoops2021',
  templateUrl: './aoops2021.component.html',
  styleUrls: ['./aoops2021.component.css']
})
export class Aoops2021Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
