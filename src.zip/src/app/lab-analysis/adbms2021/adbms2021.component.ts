import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adbms2021',
  templateUrl: './adbms2021.component.html',
  styleUrls: ['./adbms2021.component.css']
})
export class Adbms2021Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
