import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bcn2021',
  templateUrl: './bcn2021.component.html',
  styleUrls: ['./bcn2021.component.css']
})
export class Bcn2021Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
