import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aos2021',
  templateUrl: './aos2021.component.html',
  styleUrls: ['./aos2021.component.css']
})
export class Aos2021Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
