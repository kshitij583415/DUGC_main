import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bsnp2021',
  templateUrl: './bsnp2021.component.html',
  styleUrls: ['./bsnp2021.component.css']
})
export class Bsnp2021Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
