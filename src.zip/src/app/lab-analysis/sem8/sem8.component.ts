import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sem8',
  templateUrl: './sem8.component.html',
  styleUrls: ['./sem8.component.css']
})
export class Sem8Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
