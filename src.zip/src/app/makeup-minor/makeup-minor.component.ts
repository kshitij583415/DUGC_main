import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-makeup-minor',
  templateUrl: './makeup-minor.component.html',
  styleUrls: ['./makeup-minor.component.css']
})
export class MakeupMinorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
