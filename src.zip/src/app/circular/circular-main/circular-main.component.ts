import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-circular-main',
  templateUrl: './circular-main.component.html',
  styleUrls: ['./circular-main.component.css']
})
export class CircularMainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
