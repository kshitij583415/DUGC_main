import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ns',
  templateUrl: './ns.component.html',
  styleUrls: ['./ns.component.css']
})
export class NsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
