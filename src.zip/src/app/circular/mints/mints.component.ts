import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mints',
  templateUrl: './mints.component.html',
  styleUrls: ['./mints.component.css']
})
export class MintsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
 

}
