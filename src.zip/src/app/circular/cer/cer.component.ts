import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cer',
  templateUrl: './cer.component.html',
  styleUrls: ['./cer.component.css']
})
export class CerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
