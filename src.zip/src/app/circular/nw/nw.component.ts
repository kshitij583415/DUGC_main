import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nw',
  templateUrl: './nw.component.html',
  styleUrls: ['./nw.component.css']
})
export class NwComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
