import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ni',
  templateUrl: './ni.component.html',
  styleUrls: ['./ni.component.css']
})
export class NiComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
